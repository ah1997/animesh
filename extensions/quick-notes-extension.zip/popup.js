const KEY = 'notes';
const store = chrome.storage.sync || chrome.storage.local;

const $ = (id) => document.getElementById(id);
const input = $('input');
const saveBtn = $('save');
const cancelBtn = $('cancelEdit');
const search = $('search');
const list = $('list');
const empty = $('empty');
const count = $('count');

let notes = [];
let editingId = null;

function load() {
  return new Promise((resolve) => {
    store.get({ [KEY]: [] }, (res) => resolve(res[KEY] || []));
  });
}

function persist() {
  return new Promise((resolve) => store.set({ [KEY]: notes }, resolve));
}

function stamp(ts) {
  const d = new Date(ts);
  return d.toLocaleString(undefined, {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function render() {
  const q = search.value.trim().toLowerCase();
  const visible = q
    ? notes.filter((n) => n.text.toLowerCase().includes(q))
    : notes;

  list.textContent = '';
  visible.forEach((note) => list.appendChild(row(note)));

  empty.classList.toggle('hidden', visible.length > 0);
  empty.textContent = notes.length === 0
    ? 'No notes yet. Write your first one above.'
    : 'No notes match that search.';
  count.textContent = notes.length ? `${notes.length} note${notes.length > 1 ? 's' : ''}` : '';
}

function row(note) {
  const li = document.createElement('li');
  li.className = 'note';

  const p = document.createElement('p');
  p.className = 'note-text';
  p.textContent = note.text;

  const meta = document.createElement('div');
  meta.className = 'note-meta';

  const time = document.createElement('span');
  time.className = 'stamp';
  time.textContent = stamp(note.updatedAt || note.createdAt) + (note.updatedAt ? ' · edited' : '');

  const actions = document.createElement('div');
  actions.className = 'row-actions';

  const copy = document.createElement('button');
  copy.className = 'icon-btn';
  copy.textContent = 'Copy';
  copy.addEventListener('click', async () => {
    await navigator.clipboard.writeText(note.text);
    copy.textContent = 'Copied';
    setTimeout(() => (copy.textContent = 'Copy'), 1200);
  });

  const edit = document.createElement('button');
  edit.className = 'icon-btn';
  edit.textContent = 'Edit';
  edit.addEventListener('click', () => startEdit(note));

  const del = document.createElement('button');
  del.className = 'icon-btn delete';
  del.textContent = 'Delete';
  del.addEventListener('click', () => remove(note.id, del));

  actions.append(copy, edit, del);
  meta.append(time, actions);
  li.append(p, meta);
  return li;
}

function startEdit(note) {
  editingId = note.id;
  input.value = note.text;
  input.focus();
  saveBtn.textContent = 'Update';
  cancelBtn.classList.remove('hidden');
}

function resetComposer() {
  editingId = null;
  input.value = '';
  saveBtn.textContent = 'Save';
  cancelBtn.classList.add('hidden');
}

async function submit() {
  const text = input.value.trim();
  if (!text) { input.focus(); return; }

  if (editingId) {
    const n = notes.find((x) => x.id === editingId);
    if (n) { n.text = text; n.updatedAt = Date.now(); }
  } else {
    notes.unshift({ id: crypto.randomUUID(), text, createdAt: Date.now(), updatedAt: null });
  }

  resetComposer();
  await persist();
  render();
}

let pendingDelete = null;
async function remove(id, btn) {
  if (pendingDelete !== id) {
    pendingDelete = id;
    btn.textContent = 'Sure?';
    setTimeout(() => {
      if (pendingDelete === id) { pendingDelete = null; btn.textContent = 'Delete'; }
    }, 2500);
    return;
  }
  pendingDelete = null;
  notes = notes.filter((n) => n.id !== id);
  if (editingId === id) resetComposer();
  await persist();
  render();
}

saveBtn.addEventListener('click', submit);
cancelBtn.addEventListener('click', resetComposer);
search.addEventListener('input', render);

input.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') submit();
  if (e.key === 'Escape' && editingId) resetComposer();
});

(async () => {
  notes = await load();
  render();
  input.focus();
})();
