"use strict";

/* ===========================================================
   Injected into the page — must be fully self-contained
   (no references to outer popup.js scope).
   =========================================================== */
function extractPageData() {
  function metaContent(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        const c = el.getAttribute("content");
        if (c && c.trim()) return c.trim();
      }
    }
    return null;
  }
  function metaContentAll(selectors) {
    const out = [];
    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach((el) => {
        const c = el.getAttribute("content");
        if (c && c.trim()) out.push(c.trim());
      });
    }
    return out;
  }

  const result = {
    url: location.href,
    hostname: location.hostname,
    pageTitle: document.title,
  };

  result.title = metaContent(['meta[name="citation_title"]']);
  result.authors = metaContentAll(['meta[name="citation_author"]']);
  result.dcAuthors = metaContentAll([
    'meta[name="dc.creator"]',
    'meta[name="DC.creator"]',
    'meta[name="author"]',
  ]);
  result.journal = metaContent(['meta[name="citation_journal_title"]']);
  result.conference = metaContent(['meta[name="citation_conference_title"]']);
  result.bookTitle = metaContent([
    'meta[name="citation_book_title"]',
    'meta[name="citation_inbook_title"]',
  ]);
  result.volume = metaContent(['meta[name="citation_volume"]']);
  result.issue = metaContent(['meta[name="citation_issue"]']);
  result.firstpage = metaContent(['meta[name="citation_firstpage"]']);
  result.lastpage = metaContent(['meta[name="citation_lastpage"]']);
  result.doi = metaContent(['meta[name="citation_doi"]']);
  result.isbn = metaContent(['meta[name="citation_isbn"]']);
  result.issn = metaContent(['meta[name="citation_issn"]']);
  result.publisher = metaContent(['meta[name="citation_publisher"]']);
  result.pubDate = metaContent([
    'meta[name="citation_publication_date"]',
    'meta[name="citation_online_date"]',
    'meta[name="citation_date"]',
    'meta[property="article:published_time"]',
    'meta[name="dc.date"]',
    'meta[name="DC.date"]',
  ]);
  result.ogType = metaContent(['meta[property="og:type"]']);
  result.ogTitle = metaContent(['meta[property="og:title"]']);
  result.ogSiteName = metaContent(['meta[property="og:site_name"]']);

  result.ldAuthors = [];
  result.ldPublisher = null;
  result.ldHeadline = null;
  result.ldDatePublished = null;
  result.ldIsbn = null;
  result.ldType = null;

  try {
    const scripts = Array.from(
      document.querySelectorAll('script[type="application/ld+json"]')
    );
    for (const s of scripts) {
      let data;
      try {
        data = JSON.parse(s.textContent);
      } catch (e) {
        continue;
      }
      const items = Array.isArray(data) ? data : data["@graph"] || [data];
      for (const item of items) {
        if (!item || typeof item !== "object") continue;
        const t = item["@type"];
        if (!result.ldType && t) result.ldType = Array.isArray(t) ? t.join(",") : t;
        if (!result.ldHeadline && item.headline) result.ldHeadline = item.headline;
        if (!result.ldDatePublished && item.datePublished)
          result.ldDatePublished = item.datePublished;
        if (result.ldAuthors.length === 0 && item.author) {
          const a = item.author;
          if (Array.isArray(a)) {
            result.ldAuthors = a
              .map((x) => (typeof x === "string" ? x : x && x.name))
              .filter(Boolean);
          } else if (typeof a === "object" && a && a.name) {
            result.ldAuthors = [a.name];
          } else if (typeof a === "string") {
            result.ldAuthors = [a];
          }
        }
        if (!result.ldPublisher && item.publisher) {
          result.ldPublisher =
            typeof item.publisher === "object" ? item.publisher.name : item.publisher;
        }
        if (!result.ldIsbn && item.isbn) result.ldIsbn = item.isbn;
      }
    }
  } catch (e) {
    /* ignore malformed JSON-LD */
  }

  result.isWikipedia = /(^|\.)wikipedia\.org$/.test(location.hostname);
  result.wgPageName = null;
  result.wgRevisionId = null;
  if (result.isWikipedia) {
    try {
      if (window.mw && window.mw.config && window.mw.config.get) {
        result.wgPageName = window.mw.config.get("wgPageName");
        result.wgRevisionId = window.mw.config.get("wgRevisionId");
      }
    } catch (e) {
      /* ignore */
    }
    if (!result.wgRevisionId) {
      const permalink = document.querySelector(
        "#t-permalink a, li#t-permalink a"
      );
      if (permalink) {
        const href = permalink.getAttribute("href") || "";
        const m = href.match(/oldid=(\d+)/);
        if (m) result.wgRevisionId = m[1];
        const tm = href.match(/title=([^&]+)/);
        if (tm && !result.wgPageName) result.wgPageName = decodeURIComponent(tm[1]);
      }
    }
  }

  return result;
}

/* ===========================================================
   Popup logic
   =========================================================== */
(function () {
  const MONTHS = ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
  const MONTHS_FULL = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  const els = {
    status: document.getElementById("status"),
    rescan: document.getElementById("rescan"),
    tabs: Array.from(document.querySelectorAll(".tab")),
    journalLabel: document.getElementById("f-journal-label"),

    title: document.getElementById("f-title"),
    authors: document.getElementById("f-authors"),
    orgAuthor: document.getElementById("f-orgauthor"),
    journal: document.getElementById("f-journal"),
    volume: document.getElementById("f-volume"),
    number: document.getElementById("f-number"),
    pages: document.getElementById("f-pages"),
    publisher: document.getElementById("f-publisher"),
    doi: document.getElementById("f-doi"),
    isbn: document.getElementById("f-isbn"),
    address: document.getElementById("f-address"),
    url: document.getElementById("f-url"),
    note: document.getElementById("f-note"),
    year: document.getElementById("f-year"),
    month: document.getElementById("f-month"),
    extra: document.getElementById("f-extra"),
    key: document.getElementById("f-key"),

    output: document.getElementById("output"),
    copyBtn: document.getElementById("copy-btn"),
    downloadBtn: document.getElementById("download-btn"),
    copyFeedback: document.getElementById("copy-feedback"),
  };

  const state = { type: "article", keyManuallyEdited: false };

  /* ---------- utilities ---------- */

  function setStatus(msg, ok) {
    els.status.textContent = msg;
    els.status.classList.toggle("ok", !!ok);
  }

  function parseDateString(str) {
    if (!str) return { year: "", month: "" };
    let m = str.match(/(\d{4})[\/\-.](\d{1,2})(?:[\/\-.](\d{1,2}))?/);
    if (m) {
      const year = m[1];
      const mi = parseInt(m[2], 10);
      const month = mi >= 1 && mi <= 12 ? MONTHS[mi - 1] : "";
      return { year, month };
    }
    m = str.match(/(\d{4})/);
    const year = m ? m[1] : "";
    const lower = str.toLowerCase();
    let month = "";
    for (let i = 0; i < MONTHS_FULL.length; i++) {
      if (lower.includes(MONTHS_FULL[i].toLowerCase())) {
        month = MONTHS[i];
        break;
      }
    }
    return { year, month };
  }

  function formatAccessedNote(date) {
    date = date || new Date();
    const day = date.getDate();
    const month = MONTHS_FULL[date.getMonth()].slice(0, 3);
    const year = date.getFullYear();
    return `[Online; accessed ${day}. ${month}. ${year}]`;
  }

  function buildWikiUrl(d) {
    if (d.wgPageName && d.wgRevisionId) {
      return `https://${d.hostname}/w/index.php?title=${d.wgPageName}&oldid=${d.wgRevisionId}`;
    }
    return d.url;
  }

  function slugify(s) {
    return (s || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]/g, "");
  }

  function esc(v) {
    if (v === undefined || v === null) return "";
    return String(v)
      .replace(/\\/g, "\\\\")
      .replace(/([{}&%$#_])/g, "\\$1");
  }

  /* ---------- type tab visibility ---------- */

  function applyTypeVisibility(type) {
    document.querySelectorAll("[data-types]").forEach((el) => {
      const types = el.getAttribute("data-types").split(" ");
      el.style.display = types.includes("all") || types.includes(type) ? "" : "none";
    });
    els.journalLabel.textContent = type === "book" ? "Database / Platform" : "Journal";
  }

  function setActiveType(type) {
    state.type = type;
    els.tabs.forEach((t) => t.classList.toggle("active", t.dataset.type === type));
    applyTypeVisibility(type);
  }

  /* ---------- citation key ---------- */

  function firstAuthorSurname() {
    const raw = els.authors.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean)[0];
    if (!raw) return "";
    if (raw.includes(",")) return raw.split(",")[0].trim();
    const parts = raw.split(/\s+/);
    return parts[parts.length - 1] || raw;
  }

  function regenerateKey() {
    if (state.keyManuallyEdited) return;
    const surname = slugify(firstAuthorSurname());
    const year = els.year.value.trim();
    const monthAbbr = els.month.value;
    const monthCap = monthAbbr ? monthAbbr[0].toUpperCase() + monthAbbr.slice(1) : "";
    let key = surname + year + monthCap;
    if (!key) {
      const titleWords = (els.title.value || "ref").split(/\s+/).slice(0, 2).join("");
      key = slugify(titleWords) || "ref" + Date.now();
    }
    els.key.value = key;
  }

  /* ---------- bibtex rendering ---------- */

  function pushField(lines, name, val) {
    const v = (val || "").trim();
    if (!v) return;
    lines.push(`\t${name} = {${esc(v)}}`);
  }
  function pushBareField(lines, name, val) {
    const v = (val || "").trim();
    if (!v) return;
    lines.push(`\t${name} = ${v}`);
  }
  function buildAuthorLine() {
    const authorsRaw = els.authors.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
    if (!authorsRaw.length) return null;
    if (els.orgAuthor.checked) {
      return `\tauthor = {{${esc(authorsRaw.join(" and "))}}}`;
    }
    return `\tauthor = {${authorsRaw.map(esc).join(" and ")}}`;
  }

  function renderOutput() {
    const type = state.type;
    const lines = [];
    const al = buildAuthorLine();
    if (al) lines.push(al);

    const titleVal = els.title.value.trim();
    if (titleVal) lines.push(`\ttitle = {{${esc(titleVal)}}}`);

    if (type === "article") {
      pushField(lines, "journal", els.journal.value);
      pushField(lines, "volume", els.volume.value);
      pushField(lines, "number", els.number.value);
      pushField(lines, "pages", els.pages.value);
      pushField(lines, "year", els.year.value);
      pushBareField(lines, "month", els.month.value);
      pushField(lines, "publisher", els.publisher.value);
      pushField(lines, "doi", els.doi.value);
    } else if (type === "book") {
      pushField(lines, "journal", els.journal.value);
      pushField(lines, "isbn", els.isbn.value);
      pushField(lines, "publisher", els.publisher.value);
      pushField(lines, "year", els.year.value);
      pushBareField(lines, "month", els.month.value);
      pushField(lines, "address", els.address.value);
      pushField(lines, "doi", els.doi.value);
    } else {
      pushField(lines, "year", els.year.value);
      pushBareField(lines, "month", els.month.value);
      pushField(lines, "note", els.note.value);
      pushField(lines, "url", els.url.value);
    }

    els.extra.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean)
      .forEach((l) => lines.push(`\t${l.replace(/,\s*$/, "")}`));

    const key = els.key.value.trim() || "ref";
    const body = lines.join(",\n");
    els.output.value = `@${type}{${key},\n${body}\n}`;
  }

  /* ---------- populate from extracted page data ---------- */

  function detectType(d) {
    if (d.journal || d.doi || d.conference) return "article";
    if (d.isbn || d.ldIsbn || d.bookTitle || (d.ogType && /book/i.test(d.ogType))) return "book";
    return "misc";
  }

  function populateFromData(d) {
    if (d.isWikipedia) {
      setActiveType("misc");
      els.orgAuthor.checked = true;
      els.authors.value = "Contributors to Wikimedia projects";
      els.title.value = d.pageTitle || d.title || "";
      const now = new Date();
      els.year.value = String(now.getFullYear());
      els.month.value = MONTHS[now.getMonth()];
      els.note.value = formatAccessedNote(now);
      els.url.value = buildWikiUrl(d);
      setStatus("Detected: Wikipedia page → filed as Misc", true);
      regenerateKey();
      renderOutput();
      return;
    }

    const type = detectType(d);
    setActiveType(type);

    const authors = d.authors && d.authors.length ? d.authors : d.dcAuthors && d.dcAuthors.length ? d.dcAuthors : d.ldAuthors || [];
    els.authors.value = authors.join("\n");
    els.orgAuthor.checked = false;
    els.title.value = d.title || d.ldHeadline || d.ogTitle || d.pageTitle || "";

    const { year, month } = parseDateString(d.pubDate || d.ldDatePublished);
    els.year.value = year;
    els.month.value = month;

    if (type === "article") {
      els.journal.value = d.journal || d.conference || "";
      els.volume.value = d.volume || "";
      els.number.value = d.issue || "";
      els.pages.value =
        d.firstpage && d.lastpage && d.lastpage !== d.firstpage
          ? `${d.firstpage}--${d.lastpage}`
          : d.firstpage || d.lastpage || "";
      els.publisher.value = d.publisher || d.ldPublisher || "";
      els.doi.value = d.doi || "";
      setStatus(
        d.journal || d.doi
          ? "Detected: Article (from page metadata)"
          : "Guessed: Article — please check the fields",
        !!(d.journal || d.doi)
      );
    } else if (type === "book") {
      els.journal.value = "";
      els.isbn.value = d.isbn || d.ldIsbn || "";
      els.publisher.value = d.publisher || d.ldPublisher || "";
      els.address.value = "";
      els.doi.value = d.doi || "";
      setStatus("Detected: Book (from page metadata)", true);
    } else {
      els.url.value = d.url || "";
      els.note.value = formatAccessedNote();
      setStatus(
        els.title.value
          ? "No journal/book data found — filed as Misc"
          : "No citation metadata found — fill in manually",
        false
      );
    }

    regenerateKey();
    renderOutput();
  }

  /* ---------- init / rescan ---------- */

  async function init() {
    setStatus("Reading page…");
    state.keyManuallyEdited = false;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) throw new Error("no-tab");
      if (!/^https?:|^file:/.test(tab.url || "")) throw new Error("unsupported-scheme");

      const injections = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractPageData,
      });
      const data = injections && injections[0] && injections[0].result;
      if (!data) throw new Error("no-data");
      populateFromData(data);
    } catch (err) {
      let tab = null;
      try {
        [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      } catch (e) {
        /* ignore */
      }
      setActiveType("misc");
      els.title.value = (tab && tab.title) || "";
      els.url.value = (tab && tab.url) || "";
      els.note.value = formatAccessedNote();
      setStatus("Can't read this page automatically — fill in the fields by hand.", false);
      regenerateKey();
      renderOutput();
    }
  }

  /* ---------- events ---------- */

  els.tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      setActiveType(tab.dataset.type);
      regenerateKey();
      renderOutput();
    });
  });

  const watchedInputs = [
    els.title, els.authors, els.journal, els.volume, els.number, els.pages,
    els.publisher, els.doi, els.isbn, els.address, els.url, els.note,
    els.year, els.extra,
  ];
  watchedInputs.forEach((el) => {
    el.addEventListener("input", () => {
      regenerateKey();
      renderOutput();
    });
  });
  [els.month, els.orgAuthor].forEach((el) => {
    el.addEventListener("change", () => {
      regenerateKey();
      renderOutput();
    });
  });

  els.key.addEventListener("input", () => {
    state.keyManuallyEdited = true;
    renderOutput();
  });

  els.rescan.addEventListener("click", init);

  // Apply default tab's field visibility immediately so the form doesn't
  // flash with every type's fields visible while the page scan is in flight.
  setActiveType(state.type);

  let feedbackTimer;
  function showCopyFeedback(msg) {
    els.copyFeedback.textContent = msg;
    clearTimeout(feedbackTimer);
    feedbackTimer = setTimeout(() => {
      els.copyFeedback.textContent = "";
    }, 2200);
  }

  els.copyBtn.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(els.output.value);
    } catch (e) {
      els.output.focus();
      els.output.select();
      document.execCommand("copy");
    }
    showCopyFeedback("Copied to clipboard ✓");
  });

  els.downloadBtn.addEventListener("click", () => {
    const blob = new Blob([els.output.value], { type: "application/x-bibtex" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${els.key.value.trim() || "citation"}.bib`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  });

  init();
})();
