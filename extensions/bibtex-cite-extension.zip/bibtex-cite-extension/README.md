# Cite It — BibTeX Citation Grabber

A Chrome extension that reads the page you're on and hands you a ready-to-edit
BibTeX entry — `@article`, `@book`, or `@misc` — with no server round-trip.
Everything happens locally, in your browser.

## Install it (unpacked, ~30 seconds)

1. Unzip this folder somewhere permanent (don't delete it later — Chrome
   loads the extension directly from these files).
2. Open `chrome://extensions` in Chrome.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the `bibtex-cite-extension` folder
   (the one containing `manifest.json`).
5. Pin it: click the puzzle-piece icon in the toolbar, then the pin next to
   **Cite It**.

## Use it

1. Go to any page — a journal article, a publisher's book page, a Wikipedia
   article, a blog post, anything.
2. Click the **Cite It** icon.
3. It scans the page and guesses the type:
   - **Article** — if it finds journal/DOI metadata (works great on
     publisher sites: APS, Springer, IEEE, Nature, arXiv, PubMed, etc.)
   - **Book** — if it finds an ISBN or book metadata
   - **Misc** — everything else, including a Wikipedia-specific mode that
     fills in the contributor byline, revision-stable URL, and an
     "accessed on" note automatically
4. Every field is editable — switch the type tab yourself if the guess is
   wrong, fix anything the page got wrong or left out, then hit **Copy** or
   **Download .bib**.

The **⟲** button in the top-right re-scans the current page (handy on
single-page apps where content loads after you opened the popup, or after
you navigate).

## How detection works

The extension reads standard metadata that most academic publishers,
Google Scholar, and Zotero all rely on — `citation_*` meta tags, Dublin
Core tags, Open Graph tags, and `application/ld+json` structured data —
plus a couple of Wikipedia-specific hooks (`mw.config`, the permalink) for
a citation that matches Wikipedia's own "Cite this page" output.

Not every website publishes this metadata. When it's thin or missing, the
extension falls back to the page's `<title>` and URL and files the entry
as **Misc** — you'll just need to fill in more by hand. There's no way to
guarantee perfect extraction on every website; the goal is to save you the
typing on the sites that do publish good metadata, and get you a clean
starting template everywhere else.

## Privacy

The extension only reads the page you're actively looking at, and only at
the moment you click the icon (`activeTab` permission — no "read your data
on every site you visit" prompt at install). Nothing is sent anywhere;
there's no network request, no analytics, no background script.

## Files

```
bibtex-cite-extension/
├── manifest.json     Extension configuration (Manifest V3)
├── popup.html         Popup markup
├── popup.css          Popup styling
├── popup.js           Extraction + BibTeX generation logic
├── icons/              Toolbar icons (16/48/128px)
└── README.md          This file
```
